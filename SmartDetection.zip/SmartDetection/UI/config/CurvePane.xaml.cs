﻿

using RestSharp;
using RestSharp.Authenticators;
using SmartDetection.biz;
using SmartDetection.https;
using SmartDetection.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using System.Text.Json;
using System.IO;
using Newtonsoft.Json;
using SmartDetection.dataType;
using System.Collections.ObjectModel;

namespace SmartDetection.UI.config
{
    /// <summary>
    /// LineBrokenWindows.xaml 的交互逻辑
    /// </summary>
    public partial class CurvePane : UserControl
    {
        List<string[]> Lines = null;

        List<CurveInfo> Curvenfos = new List<CurveInfo>();

        Dictionary<string, string> keyValues = new Dictionary<string, string>();
        public int selectIndex = 0;
        public int lineNo = 0;
        public int lineType = 0;
        AppTools appTools;
        public CurvePane()
        {

            InitializeComponent();
            appTools = AppTools.GetInstance();
            initLines();
            initLinesType();
        }

        public async void initLinesType()
        {
            // /system/dict/ts_row_type
            var service = new RestSharpService(new RestClient());
            var url = appTools.web_base + "/system/dict/ts_row_type";
            Dictionary<string, string> dir = new Dictionary<string, string>();
            string r = await service.GetAsync<string>(url, dir);
            if (r != null)
            {
                JsonNode ee = JsonNode.Parse(r);
                JsonArray str = (JsonArray)ee["data"];
                List<LineInfo> list = new List<LineInfo>();
                foreach (JsonNode node in str)
                {
                    LineInfo cinfo = new LineInfo();
                    cinfo.lineNo = node["dictCode"].ToString();
                    cinfo.lineName = node["dictName"].ToString();
                    list.Add(cinfo);
                }
                /**
                 * 与界面上的UI对象绑定
                 */
                linesType.ItemsSource = list;
                linesType.DisplayMemberPath = "lineName";
                linesType.SelectedValuePath = "lineName";
            }


        }
        public async void initLines()
        {
            Curvenfos.Clear();
            var service = new RestSharpService(new RestClient());
            var url = appTools.web_base + "/lineinfo/list";
            Dictionary<string, string> dir = new Dictionary<string, string>();
            /**
             * 注意：这是添加URL后面的参数形式
             * 
            //dir.Add("lineName","京九");
            //dir.Add("rowType" ,"下");
            */
            string r = await service.GetAsync<string>(url, dir);
            /**
             * 以下是将返回的字符串转化为JSON
             * 并生成list对象
             */
            if (r != null)
            {
                JsonNode ee = JsonNode.Parse(r);
                JsonArray str = (JsonArray)ee["data"];
                List<LineInfo> list = new List<LineInfo>();
                foreach (JsonNode node in str)
                {
                    LineInfo cinfo = new LineInfo();
                    cinfo.lineNo = node["lineNo"].ToString();
                    cinfo.lineName = node["lineName"].ToString();
                    list.Add(cinfo);
                }
                /**
                 * 与界面上的UI对象绑定
                 */
                lines.ItemsSource = list;
                lines.DisplayMemberPath = "lineName";
                lines.SelectedValuePath = "lineName";
            }
        }

        private async void line_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int index = lines.SelectedIndex;
                string lineName = "";
                if (index != -1)
                {
                    lineName = lines.SelectedValue.ToString();
                }
                string lineTypeName = "";
                int lineTypeIndex = linesType.SelectedIndex;
                if (lineTypeIndex != -1)
                {
                    lineTypeName = linesType.SelectedValue.ToString();
                }

                var service = new RestSharpService(new RestClient());
                var url = appTools.web_base + "/minor-radius-curve/curve/list";
                Dictionary<string, string> dir = new Dictionary<string, string>();
                /**
                 * 注意：这是添加URL后面的参数形式
                 *   
                 */
                // dir.Add("lineName", lineName);
                dir.Add("lineName", "京九");
                dir.Add("rowType", lineTypeName);
                string r = await service.GetAsync<string>(url, dir);
                if (r != null)
                {

                    JsonNode res = JsonNode.Parse(r);
                    JsonArray str = (JsonArray)res["data"];
                    List<minorRadiusCurveRow> list = new List<minorRadiusCurveRow>();

                    foreach (JsonNode node in str)
                    {
                        minorRadiusCurveRow curveInfo = new minorRadiusCurveRow();
                        curveInfo.lineName = node["lineName"].ToString();
                        curveInfo.rowType = node["rowType"].ToString();
                        string v = node["startMileage"].ToString();
                        curveInfo.startMileage = double.Parse(v);
                        curveInfo.endMileage = (double)node["endMileage"];
                        curveInfo.curveDirection = node["curveDirection"].ToString();
                        curveInfo.curveRadius = (double)node["curveRadius"];
                        curveInfo.curveLength = (double)node["curveLength"];
                        curveInfo.speedLimit = node["speedLimit"].ToString();
                        curveInfo.remark = node["remark"].ToString();
                        list.Add(curveInfo);

                    }
                    CurveData.ItemsSource = list;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        public void refreshBridgeData()
        {



        }
        public void refreshTunnelData()
        {



        }
        public void refreshCurveData()
        {
            //string sql = "";
            //List<CurveInfo> dataList = new List<CurveInfo>();
            //if (lineType == 0)
            //{
            //    sql = "select * from curve where lineno=" + lineNo + " and updown =" + updown;
            //}
            //else
            //{
            //    sql = "select * from curve where lineno=" + lineNo + " and updown =" + lineType;

            //}
            //List<string[]> rows = SqliteHelper.GetInstance().QueryTable(sql);
            //for (int i = 0; i < rows.Count; i++)
            //{
            //    CurveInfo curve = new CurveInfo();
            //    //然后给这一行的每一列都赋值
            //    curve.id = rows[i][0];
            //    curve.lineNo = rows[i][1];
            //    curve.updown = rows[i][2];

            //    curve.sPoint = rows[i][3];
            //    curve.ePoint = rows[i][4];
            //    curve.lr = rows[i][5];
            //    curve.radius = rows[i][6];
            //    curve.mySpeed= rows[i][7];
            //    dataList.Add(curve);
            //}

            //CurveData.ItemsSource = dataList;

        }


        private void SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void TabSelectionChanged(object sender, SelectionChangedEventArgs e)
        {


        }

        private void CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {


            //CurveInfo eData = (CurveInfo)e.Row.Item;
            //if (eData != null)
            //{
            //    SqliteHelper.GetInstance().ExecuteQuery(eData.toUpdateSql());

            //    //refreshData();
            //}
        }

        private void BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {

        }
    }
}
