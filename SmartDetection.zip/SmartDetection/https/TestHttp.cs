﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SmartDetection.https
{
    public class TestHttp
    {
        public void test()
        {
            var service = new RestSharpService(new RestClient());
            var url = "http://47.122.7.96:8010";
            Task<string> r = service.GetAsync<string>(url);
            Console.WriteLine(r);
            Console.ReadKey();
        }
        public string test2()
        {
            var url = $"http://http://47.122.7.96:8010/login";
            var client = new RestClient(url);
            var request = new RestRequest();
            request.RequestFormat = DataFormat.Json;
            var body = new { lineName= "京九", rowType = "下" };
            request.AddHeader("Content-Type", "application/json; charset=utf-8");
            request.AddParameter( JsonConvert.SerializeObject(body), ParameterType.UrlSegment);
           // var param = JsonConvert.SerializeObject(baseRequest.Parameter);
            RestResponse response = client.Execute(request);
            var responseContent = response.Content;
            return responseContent;
        }
        public async Task<string> Save(string model, string token)
        {
            var url = $"http://127.0.0.1/app/visitor/save";
            var client = new RestClient(url);
            var request = new RestRequest();
            request.RequestFormat = DataFormat.Json;
            request.AddHeader("token", token);
            request.AddParameter("application/json; charset=utf-8", JsonConvert.SerializeObject(model), ParameterType.RequestBody);
            RestResponse response = client.Execute(request);
            var responseContent = response.Content;
            return responseContent;
        }
        /// 上传文件
        /// </summary>
        /// <param name="bt"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task<string> Upload(byte[] bt, string token)
        {
            var url = $"http://127.0.0.1/tenant/common/upload";
            var client = new RestClient(url);
            var request = new RestRequest();
            request.RequestFormat = DataFormat.Json;
            request.AddHeader("token", token);
            request.AddFile("file", bt, "multipart/form-data");
            RestResponse response = client.Execute(request);
            var responseContent = response.Content;
            return responseContent;
        }

    }
}
