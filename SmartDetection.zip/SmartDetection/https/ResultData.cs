﻿using RestSharp;
using SmartDetection.biz;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;

namespace SmartDetection.https
{
    public class ResultData
    {
        public string code { set; get; }    
        public string msg { set; get; }
        
        public IList<CurveInfo> data{ set; get; } 
    }
}
