﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDetection.https
{
    public class RestSharpRequestHandler
    {
        private RestClient client;
        private RestRequest request;

        public RestSharpRequestHandler()
        {
            var options = new RestClientOptions()
            {
                ThrowOnAnyError = true,  //设置不然不会报异常
                MaxTimeout = 1000
            };
            client = new RestClient(options);
            
        }


        public string Post(string url, string str, string content_type = "application/json; charset=UTF-8")
        {
            try
            {

                this.request = new RestRequest(url)
                    .AddHeader("Content-Type", $"{content_type}; charset=UTF-8")
                    .AddStringBody(str, DataFormat.Json);

                var response = client.Post(request);
                Newtonsoft.Json.Linq.JObject jo = Newtonsoft.Json.Linq.JObject.Parse(response.Content);


                return jo.ToString();
            }
            catch (Exception ex)
            {

                return "连接服务器出错：\r\n" + ex.Message;
            }

        }

        public string Get(string url, string content_type = "application/json; charset=UTF-8")
        {
            try
            {
                request = new RestRequest(url);
                request.AddParameter("lineName", "京九");
                request.AddParameter("rowType", "下");
                var response = client.Get(request);
                JObject jo = JObject.Parse(response.Content);
                return jo.ToString();
            }
            catch (Exception ex)
            {
                return "连接服务器出错：\r\n" + ex.Message;
            }

        }
    }
}
