﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Polly;
using JsonSerializer = System.Text.Json.JsonSerializer;
using System.Diagnostics;
using SmartDetection.Utils;

namespace SmartDetection.https
{
    public class RestSharpService : IHttpService
    {
        private readonly RestClient _client;
        private int _maxRetryAttempts = 2;//重试次数
        private double _pauseBetweenFailuresSecond = 1d;  //失败后的暂停多久重试 单位s
        private AppTools appTools = AppTools.GetInstance();

        public RestSharpService(RestClient restClient)
        {
            _client = restClient;
        }

        public async Task<string> ExecutePostAsync(BaseRequest baseRequest)
        {
            try
            {
                if (string.IsNullOrEmpty(baseRequest.Url))
                {
                    return "Url is Empty";
                }
                var url = new Uri(baseRequest.Url);
                var request = new RestRequest(url, baseRequest.Method);
                request.AddHeader("Content-Type", baseRequest.ContentType);
                var param = JsonConvert.SerializeObject(baseRequest.Parameter);
                if (baseRequest.Parameter != null)
                {
                    request.AddParameter("application/json", param, ParameterType.RequestBody);
                }

                var response = await RestResponseWithPolicyAsync(request);

                if (response.StatusCode == 0)
                {
                    return response.Content;
                }

                if (response.ErrorException != null)
                {
                    return response.ErrorException.Message;
                }

                return response.ErrorMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public async Task<string> ExecuteGetAsync(BaseRequest baseRequest)
        {
            try
            {
                if (string.IsNullOrEmpty(baseRequest.Url))
                {
                    return "Url is Empty";
                }
                var url = new Uri(baseRequest.Url);
                var request = new RestRequest(url, baseRequest.Method);
              //  request.AddHeader("Content-Type", baseRequest.ContentType);
                var param = JsonConvert.SerializeObject(baseRequest.Parameter);
                if (baseRequest.Parameter != null)
                {
                    request.AddParameter( param, ParameterType.UrlSegment);
                }

                var response = await RestResponseWithPolicyAsync(request);
                response.RootElement = "data";
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return response.Content;
                }

                if (response.ErrorException != null)
                {
                    return response.ErrorException.Message;
                }

                return response.ErrorMessage;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /// <summary>
        /// 使用Policy执行http请求
        /// </summary>
        /// <param name="restRequest"></param>
        /// <returns></returns>
        private Task<RestResponse> RestResponseWithPolicyAsync(RestRequest restRequest)
        {
            var retryPolicy = Policy
                .HandleResult<RestResponse>(x => !x.IsSuccessful)
                .WaitAndRetryAsync(_maxRetryAttempts, x => TimeSpan.FromSeconds(_pauseBetweenFailuresSecond), (restResponse, timeSpan, retryCount, context) =>
                {
                    Console.WriteLine($"The request failed. HttpStatusCode={restResponse.Result.StatusCode}. " +
                        $"\nWaiting {timeSpan.TotalSeconds} seconds before retry. Number attempt {retryCount}." +
                        $"\n Uri={restResponse.Result.ResponseUri}; " +
                        $"\nRequestResponse={restResponse.Result.Content}"
                        + $"\nErrorMessage={restResponse.Result.ErrorMessage}");
                });

            var circuitBreakerPolicy = Policy
                .HandleResult<RestResponse>(x => x.StatusCode == HttpStatusCode.ServiceUnavailable)
                .CircuitBreakerAsync(1, TimeSpan.FromSeconds(60), onBreak: (restResponse, timespan, context) =>
                {
                    Console.WriteLine($"Circuit went into a fault state. Reason: {restResponse.Result.Content}");
                },
                onReset: (context) =>
                {
                    Console.WriteLine($"Circuit left the fault state.");
                });

            return retryPolicy.WrapAsync(circuitBreakerPolicy).ExecuteAsync(() => _client.ExecuteAsync(restRequest));
        }

        public async Task<TResponse> GetAsync<TResponse>(string url) where TResponse : class
        {
            var text = await ExecuteGetAsync(new BaseRequest()
            {
                Url = url,
                Method = Method.Get,
            });
            return (typeof(TResponse) == typeof(string)) ? ((text as TResponse)) : (ToJsonModel<TResponse>(text));
        }
        public async Task<TResponse> GetAsync<TResponse>(string url,object param) where TResponse : class
        {
            var text = await ExecuteGetAsync(new BaseRequest()
            {
                Url = url,
                Method = Method.Get,
                Parameter = param,
                
            });
            
            return (typeof(TResponse) == typeof(string)) ? ((text as TResponse)) : (ToJsonModel<TResponse>(text));
        }
        public async Task<TResponse> PostAsync<TResponse>(string url, object param) where TResponse : class
        {
            var text = await ExecutePostAsync(new BaseRequest()
            {
                Url = url,
                Method = Method.Post,
                Parameter = param
            });
            return (typeof(TResponse) == typeof(string)) ? ((text as TResponse)) : (ToJsonModel<TResponse>(text));
        }

        public T ToJsonModel<T>(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return default(T);
            }

            JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                NumberHandling = JsonNumberHandling.AllowReadingFromString
                //NumberHandling = JsonNumberHandling.WriteAsString,
            };
            //  jsonSerializerOptions.Converters.Add(new DateTimeConverterUsingDateTimeParse());
            return JsonSerializer.Deserialize<T>(json, jsonSerializerOptions);
        }
     
    }
}
