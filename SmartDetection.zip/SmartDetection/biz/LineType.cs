﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDetection.biz
{
    public class LineType
    {
        public LineType(string item,string val) { 
        this.ItemName = item;
            this.ItemValue = val;
        }
        public string ItemName{ set; get; }
        public string ItemValue { set; get; }
    }
}
