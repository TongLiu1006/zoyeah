﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace SmartDetection.biz
{
    public class CurveInfo
    {
        public UInt64 id { set; get; }

        public string createBy { set; get; }
        public int createId { set; get; }
        public DateTime createTime { set; get; }
        public string curveDirection { set; get; }
        public int curveLength { set; get; }
        public int curveRadius { set; get; }
        public decimal endMileage { set; get; }
        public int isDelete { set; get; }
        public string lineNo { set; get; }
        public string lineName { set; get; }
        public string remark { set; get; }
        public string rowType { set; get; }
        public string speedLimit { set; get; }
        public decimal startMileage { set; get; }

        public static implicit operator CurveInfo(JsonNode v)
        {
            throw new NotImplementedException();
        }
    }
}
