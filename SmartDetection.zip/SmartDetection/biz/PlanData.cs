﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDetection.biz
{
    internal class PlanData
    {
        public PlanData() { }
        public string id { set; get; }
        public string name;
        public string description;
        public string type;
         
    }
}
