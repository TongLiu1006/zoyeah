﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDetection.biz
{
   public class LineInfo:ViewModelBase
    {
        public string lname;
        public string lineName
        { set
            {
                lname = value;
                RaisePropertyChanged(nameof(lname));
            }get {

                return lname;
            }
        }

        public string rType;
        public string rowType
        {
            set
            {
                rType = value;
                RaisePropertyChanged(nameof(rType));
            }
            get
            {

                return rType;
            }
        }
        public string sMileage;
        public string startMileage
        {
            set
            {
                sMileage = value;
                RaisePropertyChanged(nameof(sMileage));
            }
            get
            {

                return sMileage;
            }
        }
        public string eMileage;
        public string endMileage
        {
            set
            {
                eMileage = value;
                RaisePropertyChanged(nameof(sMileage));
            }
            get
            {

                return eMileage;
            }
        }

        public string cDirection;
        public string curveDirection
        {
            set
            {
                cDirection = value;
                RaisePropertyChanged(nameof(cDirection));
            }
            get
            {

                return cDirection;
            }
        }

        public string cRadius;
        public string curveRadius
        {
            set
            {
                cRadius = value;
                RaisePropertyChanged(nameof(cRadius));
            }
            get
            {

                return cRadius;
            }
        }

        public string sLimit;
        public string speedLimit
        {
            set
            {
                sLimit = value;
                RaisePropertyChanged(nameof(sLimit));
            }
            get
            {

                return sLimit;
            }
        }
        public string rmark;
        public string remark
        {
            set
            {
                rmark = value;
                RaisePropertyChanged(nameof(rmark));
            }
            get
            {

                return sLimit;
            }
        }
        public string lNo;
        public string lineNo
        {
            set
            {
                lNo = value;
                RaisePropertyChanged(nameof(lNo));
            }
            get
            {

                return lNo;
            }
        }
    }
}
